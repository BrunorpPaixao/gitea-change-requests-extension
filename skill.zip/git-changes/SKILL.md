---
name: git-changes
description: Evaluate and execute requested code changes on the current branch. Use when the user provides change requests, review comments, diffs, or factual Gitea PR export JSON (schemaVersion 2.1-factual) in either full-key or short-key/minified form, and expects validation against the real codebase, implementation of valid requests, and concise reviewer-ready informal replies.
---

# Git Changes

## Workflow

1. Parse input format:
- Plain request or review text.
- Diff snippet.
- Factual Gitea export JSON using schema v2.1-factual envelope.
2. For JSON input, validate required envelope shape before acting:
- Accept both serialization modes:
  - full keys (`schemaVersion`, `scope`, `source`, ...)
  - short keys (`v`, `sc`, `src`, ...)
- Accept pretty or minified JSON (whitespace is not semantically relevant).
- Normalize short keys to canonical full keys before any downstream logic.
- Canonical validation after normalization:
  - `schemaVersion` must be `2.1-factual`.
  - `scope.type` must be `pull_request` or `single_conversation`.
  - `conversations` must be an array.
3. Build one actionable request per conversation, grounded in thread text:
- `threadComments = [rootComment, ...comments]`.
- Primary request text is `rootComment.text`.
4. Determine workset using factual filters first:
- Prefer `views.unresolvedLastCommentByOtherUser` when present.
- If a different user intent is explicit, follow user intent and state the override.
5. Inspect current branch state (`git status`, relevant files, and provided diff if present).
6. Check whether each request is true and compatible with existing architecture, conventions, and implementation.
7. Decide one path per request:
- Apply directly when valid.
- Apply an adjusted version when intent is valid but details are slightly wrong.
- Decline with evidence when incorrect, risky, low-value, or contradictory to the system.
8. Implement only minimal required edits.
9. Run targeted verification relevant to the change (tests, lint, or build checks when feasible).
10. Report results in a compact list keyed by the original `rootComment` text.

## Canonical JSON Model

Treat factual v2.1 as the only exporter family. Support two encodings of the same facts:
- Full-key encoding (canonical field names)
- Short-key encoding (compact agent export)

Always normalize to canonical full keys first.

Top-level keys:
- `schemaVersion`
- `scope`
- `source`
- `actors`
- `identityResolution`
- `conversations`
- optional by scope:
  - `pull_request`: `participants`, `exportOptions`, `completeness`, `ordering`, `counts`, `views`
  - `single_conversation`: those aggregation blocks may be omitted

Conversation keys:
- `conversationId`
- `filePath`
- `threadUrl`
- `resolved`
- `outdated`
- `selectionReason`
- `lineNew`
- `lineOld`
- `diffSide`
- `hunkHeader`
- optional `codeContext`
- `rootComment`
- `comments`
- `commentCount`
- `hasReplies`
- `lastCommentId`
- `lastCommentAuthor`
- `lastCommentAuthorIsCurrentUser`
- `lastCommentAuthorIsPrAuthor`
- `lastCommentAt`
- `lastCommentUrl`
- `lastCommentByOtherUser`
- optional by scope:
  - `pull_request`: `commentIdsInOrder`, `commentAuthorsInOrder` may be present
  - `single_conversation`: these may be omitted

Normalization rules:
- If required top-level shape is missing, treat input as non-export text/diff, not as exporter JSON.
- Only map known short keys from this exporter. Do not infer or map arbitrary third-party schemas.
- Do not infer missing identities from comment semantics.
- `codeContext` is conversation-level only and optional.

## Short-Key Mapping (Accepted Input)

Top-level:
- `v -> schemaVersion`
- `sc -> scope`
- `src -> source`
- `act -> actors`
- `idr -> identityResolution`
- `part -> participants`
- `opts -> exportOptions`
- `comp -> completeness`
- `ord -> ordering`
- `cnt -> counts`
- `vw -> views`
- `th -> conversations`
- `fp -> exportFingerprint`

Actors / identity:
- `me -> currentUser`
- `pra -> prAuthor`
- `mek -> currentUserKnown`
- `prak -> prAuthorKnown`

Source:
- `own -> owner`
- `pr -> prNumber`
- `at -> scrapedAt`

Conversation:
- `id -> conversationId`
- `file -> filePath`
- `url -> threadUrl` (at conversation level)
- `res -> resolved`
- `old -> outdated`
- `ln -> lineNew`
- `lo -> lineOld`
- `side -> diffSide`
- `hunk -> hunkHeader`
- `ctx -> codeContext`
- `root -> rootComment`
- `c -> comments`
- `cio -> commentIdsInOrder`
- `cao -> commentAuthorsInOrder`
- `cc -> commentCount`
- `hr -> hasReplies`
- `lid -> lastCommentId`
- `lurl -> lastCommentUrl`
- `lboo -> lastCommentByOtherUser`

Code context:
- `l -> lines`

Code context line:
- `t -> type`
- `o -> oldLine`
- `n -> newLine`
- `m -> marker`
- `x -> text`

Comment:
- `id -> id`
- `a -> author`
- `dt -> datetime`
- `x -> text`
- `dn -> displayName`

## Factual Interpretation Rules

- Exporter fields are factual context, not decisions.
- Use `actors`, `identityResolution`, and `participants` only as identity context.
- Use `views` and `counts` for deterministic workset selection and batching.
- Use `lastComment...` fields for latest-thread-state context.
- Use `codeContext` only as grounding evidence when present.
- Use `completeness` and `exportOptions` to assess confidence and possible omissions.
- Never treat exporter data as semantic judgment (priority/category/next actor/workflow state).

## Scope Handling

Use one model for both scopes:
- `scope.type = pull_request`: full PR export context.
- `scope.type = single_conversation`: same schema family with one conversation and leaner top-level/ordering duplication.

Only vary behavior by dataset size and available views/counts.

## Validation Rules

- Ground decisions in actual code and repository state; do not guess.
- Treat export JSON as evidence, not source of truth for implementation correctness.
- Preserve architecture and module boundaries.
- Reject harmful or low-value changes with short, factual reasoning.
- If a request cannot be safely executed, provide the closest safe alternative.
- If `identityResolution` indicates unknown identities, avoid overconfident statements tied to user identity.
- If `completeness` indicates partial export, explicitly mention uncertainty where relevant.

## Implementation Rules

- Keep diffs minimal and scoped per request.
- Avoid unrelated refactors.
- Reuse existing patterns and utilities.
- Do not modify generated files manually.
- Call out blocked steps (missing context, permission, failing dependency).

## Response Format (Required)

Return a flat list. For each normalized request item output:

1. `Conversation`: `<conversationId>` (or `n/a` if missing).
2. `Section`: `conversation`.
3. `rootComment`: request text from `rootComment.text`.
4. `Result`: `Done`, `Adjusted`, `Not done`, or `Needs clarification`.
5. `Why`: one short reason grounded in code/repo reality.
6. `Informal reply`: short human response to post back.

Additional rule for non-beneficial changes:

- Mark `Result: Not done`.
- `Why` must explicitly state why the change is wrong for this project (risk, regression, mismatch, duplicate, architectural conflict, or no user value).
- `Informal reply` must be short and accurate (no fluff).

Batch footer:

- Add one-line rollup: `done=X adjusted=Y not_done=Z clarification=W`.

## Informal Reply Style

- Friendly, direct, short.
- State what was changed, or why it was not changed.
- For rejected changes, be precise and constructive.
- Avoid robotic tone and unnecessary apology.
- Don't use the character ';'.
