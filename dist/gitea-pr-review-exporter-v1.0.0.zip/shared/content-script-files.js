(function attachContentScriptFiles(global) {
  global.GPREContentScriptFiles = [
    "shared/export-serializer.js",
    "content/content.js",
    "content/scrape-core.js",
    "content/helpers.js",
    "content/content-router.js",
  ];
})(globalThis);
