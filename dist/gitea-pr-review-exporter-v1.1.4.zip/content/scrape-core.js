/**
 * Content scrape core module.
 * Orchestrates scrape/test flows, block collection, filtering, and diagnostics handoff.
 */
async function scrapeUnresolvedConversations(options) {
  const { conversations, blocks, stats, normalizedOptions, diagnostics, completeness } = await collectConversations(options);
  lastDiagnostics = diagnostics;
  return buildSchemaV21Envelope(conversations, blocks, normalizedOptions, stats, completeness, {
    scopeType: "pull_request",
  });
}

async function testSelection(options) {
  const { conversations, blocks, stats, diagnostics, completeness, normalizedOptions } = await collectConversations(options);
  lastDiagnostics = diagnostics;
  HighlightModule.applySelectionHighlights(blocks, blocks);
  await refreshManualSelectionUi({ applyHighlights: false, selectionOptions: options });
  if (Boolean(options?.debug)) {
    HighlightModule.renderDebugOverlay(blocks);
  }
  return {
    preview: buildSelectionPreview(SELECTION_SNAPSHOT),
    count: conversations.length,
    stats,
    completeness,
    currentUserKnown: Boolean(normalizedOptions.userName),
    manualIncluded: conversations.filter((item) => item._selectionReason === "included_manual_override").length,
  };
}

async function testHighlights(options) {
  const { conversations, blocks, allBlocks, stats, diagnostics, completeness } = await collectConversations(options);
  lastDiagnostics = diagnostics;
  HighlightModule.applySelectionHighlights(allBlocks, blocks);
  await refreshManualSelectionUi({ applyHighlights: false, selectionOptions: options });
  if (Boolean(options?.debug)) {
    HighlightModule.renderDebugOverlay(blocks);
  }
  return { count: conversations.length, totalBlocks: allBlocks.length, stats, completeness };
}

async function collectConversations(options) {
  if (!isLikelyGiteaPrPage(window.location, document)) {
    throw new Error("This tab does not look like a Gitea pull request files/conversation page.");
  }

  const startedAt = Date.now();
  await ensureManualSelectionStateLoaded();
  const normalizedOptions = normalizeCollectionOptions(options);
  const state = createCollectionState(normalizedOptions, startedAt);

  const globalExpand = await expandGlobalHiddenConversationAreas();
  applyGlobalExpandCompleteness(state, globalExpand);

  const conversationBlocks = Array.from(document.querySelectorAll(".ui.segments.conversation-holder"));
  refreshQuoteReplyIndex();
  const allStandaloneCommentBlocks = collectStandaloneCommentBlocks(conversationBlocks);
  const standaloneCommentBlocks = normalizedOptions.ignoreComments ? [] : allStandaloneCommentBlocks;
  const allCollectableBlocks = [...conversationBlocks, ...standaloneCommentBlocks];
  setCollectionBlockTotals(
    state,
    allCollectableBlocks.length,
    normalizedOptions.ignoreComments ? allStandaloneCommentBlocks.length : 0
  );
  if (!allCollectableBlocks.length) {
    return buildEmptyCollectionResult(state);
  }

  for (const block of conversationBlocks) {
    applyThreadExpandCompleteness(state, await expandConversationIfNeeded(block));
  }
  refreshQuoteReplyIndex();
  const snapshot = await getSelectionSnapshot(normalizedOptions);
  const results = [];
  const selectedBlocks = [];
  const seenKeys = new Map();
  await collectThreadConversations(conversationBlocks, normalizedOptions, state, seenKeys, results, selectedBlocks, snapshot);
  collectStandaloneConversations(standaloneCommentBlocks, normalizedOptions, state, seenKeys, results, selectedBlocks, snapshot);
  return buildFinalCollectionResult(state, results, selectedBlocks, allCollectableBlocks);
}
